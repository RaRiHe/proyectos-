package bibliotecaXml;

public class Parse_Biblioteca {

	public static void main(String[] args) {
		Parse parser=new Parse();
		parser.parseFicheroXml("biblioteca.xml");
		parser.parseDocument();
		parser.print();

	}

}
