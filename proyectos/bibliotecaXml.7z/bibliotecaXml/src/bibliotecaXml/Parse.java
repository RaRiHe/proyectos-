package bibliotecaXml;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Parse {
	
	

		private Document dom = null;
		private ArrayList<Libro> libros = null;

		public Parse() {
			libros = new ArrayList<Libro>();
		}

		public void parseFicheroXml(String fichero) {
			// creamos una factory
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			try {
				// creamos un documentbuilder
				DocumentBuilder db = dbf.newDocumentBuilder();

				// parseamos el XML y obtenemos una representaci�n DOM
				dom = db.parse(fichero);
			} catch (ParserConfigurationException pce) {
				pce.printStackTrace();
			} catch (SAXException se) {
				se.printStackTrace();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}

		}

		public void parseDocument() {
			// obtenemos el elemento ra�z
			Element docEle = dom.getDocumentElement();

			// obtenemos el nodelist de elementos
			NodeList nl = docEle.getElementsByTagName("libro");
			if (nl != null && nl.getLength() > 0) {
				for (int i = 0; i < nl.getLength(); i++) {

					// obtenemos un elemento de la lista (persona)
					Element el = (Element) nl.item(i);

					// obtenemos una persona
					Libro L = getLibro(el);

					// lo a�adimos al array
					libros.add(L);
				}
			}
		}
		
		private Libro getLibro(Element libroEle){
			
			//para cada elemento persona, obtenemos su nombre y su edad
			String titulo = getTextValue(libroEle,"titulo");
			int a�o = Integer.parseInt(getAttribute(libroEle,"titulo","anyo"));
			String nombre = getTextValue(libroEle,"nombre");
			String apellido = getTextValue(libroEle,"apellido");
			String editor = getTextValue(libroEle,"editor");
			int paginas = getIntValue(libroEle,"paginas");
			
			//Creamos una nueva persona con los elementos le�dos del nodo
			Libro e = new Libro(titulo,a�o,nombre,apellido,editor,paginas);

			return e;		
			
		}
		private String getAttribute(Element ele, String tagName,String artName) {
			String textVal = null;
			NodeList nl = ele.getElementsByTagName(tagName);
			if(nl != null && nl.getLength() > 0) {
				Element el = (Element)nl.item(0);
				textVal = el.getAttribute(artName);
			}		
			return textVal;
		}
		
		private String getTextValue(Element ele, String tagName) {
			String textVal = null;
			NodeList nl = ele.getElementsByTagName(tagName);
			if(nl != null && nl.getLength() > 0) {
				Element el = (Element)nl.item(0);
				textVal = el.getFirstChild().getNodeValue();
			}		
			return textVal;
		}
		
		private int getIntValue(Element ele, String tagName) {				
			return Integer.parseInt(getTextValue(ele,tagName));
		}
	
		public void print(){

			Iterator it = libros.iterator();
			while(it.hasNext()) {
				Libro L=(Libro) it.next();
				L.print();
			}
		}
		
		

	}

