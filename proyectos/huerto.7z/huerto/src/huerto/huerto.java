package huerto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


class HuertoCom implements Comparable<HuertoCom>{
	int terreno=0;
	int agua=0;
	int cercania=0;
	int abono=0;
	String nombre ="";
	
	public HuertoCom(int terreno,int abono,int agua,int cercania,String nombre) {
		this.terreno=terreno;
		this.agua=agua;
		this.cercania=cercania;
		this.abono=abono;
		this.nombre = nombre;
	}
	

	@Override
	public String toString() {
		return "Mejor Opcion: "+nombre ;
	}


	@Override
	public int compareTo(HuertoCom o) {
		if(this.terreno==o.terreno) { 
			if (o.agua==this.agua) {
				if(o.cercania==this.cercania){
					return this.abono-o.abono;
					
				}else {
					
					return this.cercania-o.cercania;
				}
				
				
			}else {
				
				return this.agua-o.agua;
			}
		}else{
			
			return o.terreno-this.terreno;
		}
		
		
		
	}

	
}

public class huerto {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		ArrayList<HuertoCom> lista = new ArrayList<HuertoCom>();
		
		lista.add(new HuertoCom(25,5,10,30,"Amapola Grande"));
		lista.add(new HuertoCom(25,10,15,40,"Rosa Espinosa"));
		lista.add(new HuertoCom(30,20,25,35,"Col & Flor"));
		lista.add(new HuertoCom(30,10,30,45,"Ramon Omeol Vides"));
		lista.add(new HuertoCom(30,15,20,55,"Nemesio Labrador"));
		
		
		Collections.sort(lista);
		System.out.println(lista.get(0));


	}

}
