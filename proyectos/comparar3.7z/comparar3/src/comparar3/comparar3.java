package comparar3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class Tarea implements Comparable<Tarea>{
	int duracion=0;
	String nombre ="";
	int prioridad=0;
	public Tarea(int duracion, String nombre,int prioridad) {
		this.duracion = duracion;
		this.nombre = nombre;
		this.prioridad=prioridad;
	}
	

	@Override
	public String toString() {
		return "\nTarea [duracion=" + duracion + ", nombre=" + nombre + " ,prioridad "+ prioridad+"]";
	}


	@Override
	public int compareTo(Tarea o) {
		if(0==this.prioridad-o.prioridad) {
			return this.duracion-o.duracion;
		}else {
			return o.prioridad-this.prioridad;
		}
		
		
	}

	
}

public class comparar3 {
	
	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		ArrayList<Tarea> lista = new ArrayList<Tarea>();
		
		lista.add(new Tarea(30,"DI",10));
		lista.add(new Tarea(15,"AC",2));
		lista.add(new Tarea(60,"PC",10));
		lista.add(new Tarea(25,"FG",5));
		lista.add(new Tarea(120,"FG",5));
		lista.add(new Tarea(2,"FG",2));
		
		Collections.sort(lista);
		System.out.println(lista);

	}

}
