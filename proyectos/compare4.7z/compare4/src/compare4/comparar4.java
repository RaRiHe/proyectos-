package compare4;

import java.util.ArrayList
import java.util.Collections;
import java.util.Scanner;

class Tarea implements Comparable<Tarea>{
	int duracion=0;
	String nombre ="";
	int prioridad=0;
	public Tarea(int duracion, String nombre,int prioridad) {
		this.duracion = duracion;
		this.nombre = nombre;
		this.prioridad=prioridad;
	}
	

	@Override
	public String toString() {
		return "\nTarea [duracion=" + duracion + ", nombre=" + nombre + " ,prioridad "+ prioridad+"]";
	}


	@Override
	public int compareTo(Tarea o) {
		if(this.prioridad==o.prioridad) { 
			
			if (this.duracion==o.duracion) {
				
				return o.nombre.compareTo(this.nombre);
				
			}else {
				
				return this.duracion-o.duracion;
				
			}
		}else{
			
			return o.prioridad-this.prioridad;
		}
		
		
	}

	
}

public class comparar4 {

	public static void main(String[] args) {
			Scanner teclado = new Scanner (System.in);
			ArrayList<Tarea> lista = new ArrayList<Tarea>();
			
			lista.add(new Tarea(5,"B",10));
			lista.add(new Tarea(7,"J",10));
			lista.add(new Tarea(7,"H",10));
			lista.add(new Tarea(8,"A",3));
			lista.add(new Tarea(8,"C",5));
			lista.add(new Tarea(7,"R",3));
			
			Collections.sort(lista);
			System.out.println(lista);

		}

	}


