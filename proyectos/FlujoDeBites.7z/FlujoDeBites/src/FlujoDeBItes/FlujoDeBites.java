package FlujoDeBItes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FlujoDeBites {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream fi=null;
		FileOutputStream fo=null;
		File foto =new File("fondo.jpg");
			try {
				fi = new FileInputStream("fondo.jpg");
				fo = new FileOutputStream("fondo-copia2.jpg");
				
				byte [] b = new  byte [(int) foto.length()];
				fi.read(b);
				fo.write(b);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				try {
					fi.close();
					fo.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	}

}
