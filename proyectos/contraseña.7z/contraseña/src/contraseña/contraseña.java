package contrase�a;

import java.util.Scanner;

public class contrase�a {
	

	public static boolean comprueva (String contrase�a) {
		boolean correcto=true;
		int cont=0;
		char letras;
		
	    if (contrase�a.length()<8) {
	    	System.out.println("la contrase�a debe tener minimo 8 caracteres");
	    	correcto=false;
	    }
	    
	    for (int i = 0; i < contrase�a.length(); i++) {
	    	letras=contrase�a.charAt(i);
	    
	    	if(Character.isUpperCase(letras)) {
	    		cont ++;
	    	}
	    }
	    
	    if (cont<2) {
	    	System.out.println("la contrase�a debe tener minimo 2 letras mayusculas");
	    	correcto=false;
	    }
	    
		cont=0;
		
	    for (int i = 0; i < contrase�a.length(); i++) {
	    	letras=contrase�a.charAt(i);
	    
	    	if(Character.isLowerCase(letras)) {
	    		cont ++;
	    	}
	    }
	    
	    if (cont<3) {
	    	System.out.println("la contrase�a debe tener minimo 3 letras minusculas");
	    	correcto=false;
	    }
	    
	    cont=0;
	    
	    for (int i = 0; i < contrase�a.length(); i++) {
	    	letras=contrase�a.charAt(i);
	    
	    	if(Character.isDigit(letras)) {
	    		cont ++;
	    	}
	    } 
	    
	    if (cont==0) {
	    	System.out.println("la contrase�a debe tener minimo 1 numero");
	    	correcto=false;
	    }
	    
	    if (!contrase�a.contains("!")||contrase�a.contains("\"")||contrase�a.contains("$")||contrase�a.contains("%")||contrase�a.contains("&")||contrase�a.contains("/")||contrase�a.contains("(")||contrase�a.contains(")")) {
	    	System.out.println("la contrase�a debe tener minimo 1  de estos signos ! \" $ % & / ( ) ");
	    	correcto=false;
	    }
	    
	    if (contrase�a.contains("@")) {
	    	System.out.println("la contrase�a no debe contener @");
	    	correcto=false;
	    }
	    
	    
		return correcto;
	}
	public static void main(String[] args) {
		String contrase�a="";
		boolean salir =false;
		Scanner teclado = new Scanner(System.in);
		
		while(salir==false) {
			System.out.println("escribe la contrase�a");
			contrase�a=teclado.nextLine();
			salir=comprueva(contrase�a);
		}
		
	
		
	}
}
