package ciudades;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class ciudades {
	private static final String ORIGINAL
	= "�����������";
	private static final String REPLACEMENT
	= "aaeeiioouuu";
	public static String stripAccents(String str) {
		if (str == null) {
			return null;
		}
		char[] array = str.toCharArray();
		for (int index = 0; index < array.length; index++) {
			int pos = ORIGINAL.indexOf(array[index]);
			if (pos > -1) {
				array[index] = REPLACEMENT.charAt(pos);
			}
		}
		return new String(array);
	}

	public static void main(String[] args) {
		LinkedHashSet<String> set = new LinkedHashSet<String>();
		Scanner teclado = new Scanner (System.in);
		boolean seguir=true;
		String nombre="";
		int num=0;

		while (seguir) {
			System.out.println("dime el nombre de la ciudad ");
			nombre=teclado.nextLine();
			nombre=nombre.toLowerCase();
			nombre=nombre.trim();
			nombre=stripAccents(nombre);
			set.add(nombre);
			
			System.out.println("si no quieres a�adir mas ciudades escribe -1 ");
			num=teclado.nextInt();
			if (num==-1) {
				seguir=false;
			}
			teclado.nextLine();
		}
		System.out.println("hay "+set.size()+" ciudades");
		Iterator<String> j = set.iterator();
		while (j.hasNext()) {
			System.out.println(j.next());
		}

	}

}
