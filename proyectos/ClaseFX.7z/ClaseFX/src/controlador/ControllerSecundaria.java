package controlador;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ControllerSecundaria {

    @FXML private ResourceBundle resources;
    @FXML private URL location;
    @FXML private Button btnVolver;
    @FXML private ImageView imagen;

    @FXML
    void volver(ActionEvent event) {

    	//Mostrar otra ventana
    	try{

    		//Léeme el source del archivo que te digo fxml y te pongo el path
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/vista/VentanaPrincipal.fxml"));
    		Parent root = (Parent) fxmlLoader.load();

    		//Creame un nuevo Stage (una nueva ventana vacía)
    		//Stage stage= new Stage();
    		Stage stage = (Stage) btnVolver.getScene().getWindow();
    		
    		//Asignar al Stage la escena que anteriormente hemos leído y guardado en root
    		stage.setTitle("Ventana Secundaria");
    		stage.setScene(new Scene(root));

    		//Mostrar el Stage (ventana)
    		stage.show();

    	}
    	catch (Exception e){
    		e.printStackTrace();
    	}
    }

    @FXML
    void initialize() {
        
    }
    
}