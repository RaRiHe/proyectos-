package controlador;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ControllerDetalle {

	private ControllerPrincipal fxmlLoader;
	
	@FXML private ResourceBundle resources;
    @FXML private URL location;
    @FXML private Button btnCerrar;
    @FXML private ImageView imagen;
    @FXML private Label lblNombre;    
    @FXML private TextField txtFld_Nombre;

    @FXML
    void cerrar(ActionEvent event) {

    	//        
        fxmlLoader.recuperarDatos(txtFld_Nombre.getText());        
        
    	// get a handle to the stage    	
        Stage stage = (Stage) btnCerrar.getScene().getWindow();
        
        // do what you have to do
        stage.close();
    }

    @FXML
    void initialize() {
        
    }
    
    //
    public void setDatos(ControllerPrincipal loader, String datos) {
 
    	this.fxmlLoader = loader;
    	txtFld_Nombre.setText(datos);
    }
    
}