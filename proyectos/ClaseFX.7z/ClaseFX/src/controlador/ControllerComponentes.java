package controlador;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.TreeSet;

import org.controlsfx.control.textfield.TextFields;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ControllerComponentes {

    @FXML private ResourceBundle resources;
    @FXML private URL location;
    @FXML private Button btnCerrar;
    @FXML private ImageView imagen;
    @FXML private TextField txtField_Nombres;
    
    @FXML
    void cerrar(ActionEvent event) {

    	// get a handle to the stage
        Stage stage = (Stage) btnCerrar.getScene().getWindow();
        // do what you have to do
        stage.close();
    }

    @FXML
    void initialize() {
    	
    	ArrayList<String> nombreProfesores     = new ArrayList<String>();
    	nombreProfesores.add("JOAQUIN SABINA");
    	nombreProfesores.add("PEDRO MARMOL");
    	nombreProfesores.add("LETICIA SABATER");
    	nombreProfesores.add("ALEJANDRO SANZ");
    	nombreProfesores.add("PAZ PADILLA");    	
    	TreeSet<String> listaNombresProfesores = new TreeSet<String>(nombreProfesores);
            
    	TextFields.bindAutoCompletion(txtField_Nombres, listaNombresProfesores);        
    }
    
}