package controlador;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ControllerPrincipal {

    @FXML private ResourceBundle resources;
    @FXML private URL location;
    @FXML private Button btnSecundaria;    
    @FXML private Button btnHolaMundo;    
    @FXML private Button btnDetalle;
    @FXML private Label lblText;
    @FXML private ImageView imagen;  
    @FXML private Button btnComponentes;
    
    @FXML
    void holaMundo(ActionEvent event) {

    	//Mostrar texto en label
    	lblText.setText("Hola mundo !");
    }

    @FXML
    void escogerOpcion(KeyEvent event) {

    	switch (event.getCode()) {
        case UP:    mostrarVentana("/vista/VentanaSecudaria.fxml", "Ventana Secundaria", true, 0); break;
        case DOWN:  mostrarVentana("/vista/VentanaDetalle.fxml", "Insertar alumno", false, 1); break;
        case LEFT:  mostrarVentana("/vista/VentanaComponentes.fxml", "Componentes", false, 2); break;
		default:
			break;
    	}    	
    	
    	KeyCombination cntrlZ = new KeyCodeCombination(KeyCode.Z, KeyCodeCombination.CONTROL_DOWN);    	
    	if(cntrlZ.match(event)){
    		lblText.setText("Deshacer");
    	}    	
    }
    
    @FXML
    void ventanaSecundaria(ActionEvent event) {

    	mostrarVentana("/vista/VentanaSecudaria.fxml", "Ventana Secundaria", true, 0);    	
    }
    
    @FXML
    void ventanaDetalle(ActionEvent event) {

    	mostrarVentana("/vista/VentanaDetalle.fxml", "Insertar alumno", false, 1);
    }

    @FXML
    void verComponentes(ActionEvent event) {

    	mostrarVentana("/vista/VentanaComponentes.fxml", "Componentes", false, 2);
    }

    //Mostrar otra ventana
    private void mostrarVentana(String src, String titulo, boolean mismoStage, int ventana) {    	

    	try{

    		//Léeme el source del archivo que te digo fxml y te pongo el path
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(src));
    		Parent root = (Parent) fxmlLoader.load();

    		Stage stage = null;
    		
    		if (mismoStage) {
    			//En el mismo Stage, mostrar otra Scene
    			stage = (Stage) btnSecundaria.getScene().getWindow();	
    		}
    		else {
    			//Creame un nuevo Stage (una nueva ventana vacía)
        		stage = new Stage();
    		}    		

    		//Asignar al Stage la escena que anteriormente hemos leído y guardado en root
    		stage.setTitle(titulo);
    		stage.setResizable(false);
    		
    		if (!mismoStage) {
    			stage.initModality(Modality.APPLICATION_MODAL);
    		}    			
    		
    		//
    		stage.setScene(new Scene(root));
    		
    		if (ventana == 1) {
    		
    			//Pasar datos a la otra ventana
                ControllerDetalle controller = fxmlLoader.getController();
                controller.setDatos(this, "Nombre...");
                
                //stage.initStyle(StageStyle.UTILITY);
                //stage.initStyle(StageStyle.DECORATED);
                //stage.initStyle(StageStyle.UNDECORATED);
                //stage.initStyle(StageStyle.UNIFIED);
                //stage.initStyle(StageStyle.TRANSPARENT);                
    		}    		    		

    		//Mostrar el Stage (ventana)
    		stage.show();

    	}
    	catch (Exception e){
    		e.printStackTrace();
    	}
    }
    
    public void recuperarDatos(String info) {
 
    	lblText.setText(info);
    }

    @FXML
    void initialize() {
    	
    	//Timeline t = new Timeline(
    	//		new KeyFrame(Duration.seconds(0), new KeyValue(btnSecundaria.translateXProperty(), 0)),
    	//		new KeyFrame(Duration.seconds(1), new KeyValue(btnSecundaria.translateYProperty(), 10)),
    	//		new KeyFrame(Duration.seconds(2), new KeyValue(btnSecundaria.translateXProperty(), 80)),
    	//		new KeyFrame(Duration.seconds(3), new KeyValue(btnSecundaria.translateYProperty(), 90))
    	//		);    	
    	//t.setAutoReverse(true);
    	//t.setCycleCount(Timeline.INDEFINITE);
    	//t.play();    	
    	
    }
    
}