package nombres;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class nombre {
	private static final String ORIGINAL
	= "�����������";
	private static final String REPLACEMENT
	= "aaeeiioouuu";
	public static String stripAccents(String str) {
		if (str == null) {
			return null;
		}
		char[] array = str.toCharArray();
		for (int index = 0; index < array.length; index++) {
			int pos = ORIGINAL.indexOf(array[index]);
			if (pos > -1) {
				array[index] = REPLACEMENT.charAt(pos);
			}
		}
		return new String(array);
	}

	public static void main(String[] args) {
		HashMap <String,Integer > map = new HashMap <String,Integer>();
		Scanner teclado = new Scanner (System.in);
		boolean seguir=true;
		String nombre="";
		int num=0,valor=0;

		while (seguir) {
			System.out.println("dime el nombre de la persona");
			nombre=teclado.nextLine();
			nombre=nombre.toLowerCase();
			nombre=nombre.trim();
			nombre=stripAccents(nombre);
			
			if(!map.containsKey(nombre)) {
				map.put(nombre, 1);
			}else {
				valor=map.get(nombre);
				valor++;
				map.put(nombre, valor);
			}
			
			System.out.println("si no quieres a�adir mas nombres escribe -1 ");
			num=teclado.nextInt();
			if (num==-1) {
				seguir=false;
			}
			teclado.nextLine();
			
		}
		Set set = map.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) {
			Map.Entry mentry = (Map.Entry)iterator.next();
			System.out.println("Nombre: "+ mentry.getKey() + " - Numero: " + mentry.getValue());
		}		
		
	}

}
