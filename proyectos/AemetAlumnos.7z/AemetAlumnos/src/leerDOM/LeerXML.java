package leerDOM;

import java.io.InputStream;
import java.net.URL;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import dominio.Poblacion;

public class LeerXML {

	public static Poblacion almacenarInformacion(String codigo) {
	

		String ruta = "http://www.aemet.es/xml/municipios/localidad_" + codigo + ".xml";

		Poblacion poblacion = new Poblacion(codigo);

		try {

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			
			URL url = new URL(ruta);
			InputStream stream = url.openStream();
			
			Document doc = db.parse(stream);
			doc.getDocumentElement().normalize();

			// Leer nombre
			NodeList listaNombres = doc.getElementsByTagName("nombre");
			String nombre = listaNombres.item(0).getTextContent();
			poblacion.setNombre(nombre);
			
			//TODO eliminar
			System.out.println("Nombre ciudad: " + nombre);

			// Dias
			NodeList listaDias = doc.getElementsByTagName("dia");
			for (int i = 0; i < listaDias.getLength(); i++) {

				Node nDias = listaDias.item(i);
				Element elem = (Element) listaDias.item(i);

				// Leer Atributo fecha="2018-04-06" en etiqueta <dia/>
				Element diaElement = (Element) nDias;
				String fecha = diaElement.getAttribute("fecha");
				
				//leer datos dentro de la etiqueta <dia/>
				//estado cielo
				NodeList cielo = elem.getElementsByTagName("estado_cielo");
				Element estado = (Element) cielo.item(0);
				String esta=estado.getAttribute("descripcion");
				
				//temperatura maxima
				NodeList temM = elem.getElementsByTagName("maxima");
				Element max = (Element) temM.item(0);
				String tm=max.getTextContent();
				
				//temperaturab minima
				NodeList temMin = elem.getElementsByTagName("minima");
				Element min = (Element) temMin.item(0);
				String tmin=min.getTextContent();
				
				//Precipitacion
				NodeList preci = elem.getElementsByTagName("prob_precipitacion");
				Element pita = (Element) preci.item(0);
				String pc=pita.getTextContent();
				
				//humedad maxima
				NodeList huM = elem.getElementsByTagName("maxima");
				Element mx = (Element) huM.item(2);
				String hm=mx.getTextContent();
				
				//humedad minima
				NodeList huMin = elem.getElementsByTagName("minima");
				Element mi = (Element) huMin.item(2);
				String hmi=mi.getTextContent();
				
		
				//TODO eliminar
				System.out.println("");
				System.out.println("[_______________________________"+"Fecha: " + fecha+"_______________________________________]");
				System.out.println("");
				System.out.println("Estado del cielo: "+esta);
				System.out.println("Probabilidad de Precipitacion: "+pc);
				System.out.println("Temperatura maxima: "+tm+" tamperatura minima: "+tmin);
				System.out.println("Humedad maxima: "+hm+" Humedad minima: "+hmi);
				System.out.println("");
				System.out.println("[_______________________________________________________________________________________]");
				System.out.println("");

			}
			
			//TODO leer toda la informaci�n del XML 
			
			
			
			
			
			
			
			
			

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return poblacion;
	}

}