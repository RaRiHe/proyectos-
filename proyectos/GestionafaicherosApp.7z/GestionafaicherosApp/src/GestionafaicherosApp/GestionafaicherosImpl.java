package GestionafaicherosApp;

import gestionficheros.GestionFicheros;

public class GestionafaicherosImpl implements GestionFicheros {

}
