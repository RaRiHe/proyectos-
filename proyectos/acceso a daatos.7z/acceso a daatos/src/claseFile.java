import java.io.File;
import java.io.IOException;

public class claseFile {


	public static void main(String[] args) {
		File f=new File("fichero1.txt");
		File p=new File("C:\\Users\\DAM2\\Desktop\\Nueva carpeta");
		File d=new File ("directorio1");
		File w=new File("C:\\Windows");
		long espacio=0;
	
		
		try {
			f.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			
		}
		d.mkdir();
		System.out.println(w.getAbsoluteFile());
		espacio=w.getFreeSpace();
		System.out.println("es pacio libre "+espacio/1000000000+"Gb");
		espacio=w.getTotalSpace();
		System.out.println("espacio total usado "+espacio/1000000000+"Gb");
		espacio=w.getUsableSpace();
		System.out.println("espacio disponible "+espacio/1000000000+"Gb");
		if(w.isHidden()) {
			System.out.println("esta en oculto");
		}else {
			System.out.println("esta visible");
		}
		espacio=w.lastModified();
		System.out.println("ultima modificacion "+(espacio/1000/60));
		
		System.out.println(f.getAbsoluteFile());
		System.out.println(d.getAbsoluteFile());
		
		if(w.canWrite()) {
			System.out.println("si se puede escribir");
		}else {
			System.out.println("no se puede escribir");
		}
		String si=File.separator;
		File Xampp=new File ("c:"+si+"xampp");
		String[] content = Xampp.list();
		
		if(content==null) {
			System.out.println("no hay ficheros en el directorio espcificado");
		}else {
			for(int i =0; i < content.length;i++) {
				System.out.println(content[i]);
			}
		}
		}

}
