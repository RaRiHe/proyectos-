import java.util.ArrayList;
import java.util.Scanner;
public class ejer1 {

	public static void main(String[] args) {
		Scanner teclado=new Scanner(System.in);
		int frases=0;
		
		System.out.println("dime cuantas frases queieres poner");
		frases=teclado.nextInt();
		
		String vector[] = new String[frases];
		
		teclado.nextLine();
		
		for(int i =0;i<frases;i++) {
			System.out.println("dime la frase que quieres guardar");
			vector[i]=teclado.nextLine();
		}
		
		for(int i =0;i<frases;i++) {
			String cortar="";
			String [] resultado=new String[frases];
			cortar=vector[i];
			resultado=cortar.split(" ");
			System.out.print(resultado[1]);
			
		}
	
		
	}

}
