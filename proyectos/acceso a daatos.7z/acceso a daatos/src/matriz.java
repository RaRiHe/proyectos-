import java.io.File;


public class matriz {
	public static int none(int num) {
		int mitad=0;
		if(num%2==0) {
			mitad=num/2;
		}else {
			mitad=num/2;
			mitad++;
		}
		
		return mitad;
	}
	//"Users"+si+"DAM2"+si+"Desktop"+si+"Nueva carpeta"
	public static void main(String[] args) {
		String si=File.separator;
		File carpeta=new File ("c:"+si+"Users"+si+"DAM2"+si+"Desktop"+si+"Nueva carpeta");
		String[] content = carpeta.list();
		int mitad=none(content.length);
		String matriz[][] = new String[mitad][mitad];
		int cont=0;
		
		for(int i =0; i < mitad;i++) {
			for(int j =0; j < mitad;j++) {
				if(cont==content.length) {
					break;
				}
				matriz[i][j]=content[cont];
				cont++;
			
			}
			if(cont==content.length) {
				break;
			}
			
		}
		for(int i =0; i < mitad;i++) {
			for(int j =0; j < mitad;j++) {
				if(matriz[i][j]==null) {
					break;
				}else {
					System.out.print(matriz[i][j]+"        ");
				}
			
			}
			System.out.println("");
		}
		
	}

}
