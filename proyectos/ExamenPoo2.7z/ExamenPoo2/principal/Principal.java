package principal;

import dominio.*;
import excepciones.*;

public class Principal {

	public static void main(String[] args) {
		
		//1.- Crear Rockeros
		RockeroClasico r1     = new RockeroClasico("Elvis Presley");	
		RockeroAlternativo r2 = new RockeroAlternativo("Tame Impala");
		
		//2.- Crear Canciones
		Canción c1 = new Canción("Wearin' That Loved On Look", 166);
		Canción c2 = new Canción("Only the Strong Survive", 218);
		Canción c3 = new Canción("I'll Hold You in My Heart", 166);
		Canción c4 = new Canción("Long Black Limousine", 162);
		
		c1.mejorarCalidad(); c1.eliminarDefectos();
		c2.mejorarCalidad(); c2.eliminarDefectos();
		c3.mejorarCalidad(); c3.eliminarDefectos();
		c4.mejorarCalidad(); c4.eliminarDefectos();
		
		Canción c5 = new Canción("One More Year", 322);
		Canción c6 = new Canción("Instant Destiny", 193);
		Canción c7 = new Canción("Borderline", 274);
		Canción c8 = new Canción("Posthumous Forgiveness", 365);
		Canción c9 = new Canción("Breathe Deeper", 372);
		
		//c5.mejorarCalidad(); c5.eliminarDefectos();
		c6.mejorarCalidad(); c6.eliminarDefectos();
		c7.mejorarCalidad(); c7.eliminarDefectos();
		c8.mejorarCalidad(); c8.eliminarDefectos();
		c9.mejorarCalidad(); c9.eliminarDefectos();
		
		//3.- Crear Discos
		Disco d1 = new Disco("From Elvis in Memphis", r1);
		Disco d2 = new Disco("The Slow Rush", r2);		 
		
		try {
			
			d1.anyadirCancion(c1);
			d1.anyadirCancion(c2);
			d1.anyadirCancion(c3);
			d1.anyadirCancion(c4);
			
			d2.anyadirCancion(c5);
			d2.anyadirCancion(c6);
			d2.anyadirCancion(c7);
			d2.anyadirCancion(c8);
			d2.anyadirCancion(c9);
			
		} catch (CancionNoEditadaException e) {

			System.out.println(e.mensajeError());			
		}		
		
		//4.- Ordenar Discos
		d1.ordenarCanciones();		
		d2.ordenarCanciones();
		
		//5.- Imprimir número de rockeros
		System.out.println();
		System.out.println("Número de rockeros: " + Rockero.getNumRockeros());
		System.out.println();
		
		//6.- Imprimir Discos
		try {
			d1.imprimirDisco();
			d2.imprimirDisco();
			
		} catch (DiscoIncompletoException e) {
			
			System.out.println(e.mensajeError());			
		}				
	}

}
