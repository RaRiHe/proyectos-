package ExamenPoo2.interfaces;

public interface Remasterizable {
    final  int SIN_DEFECTOS = 33;
    final  int CON_DEFECTOS = 34;
    final  int BUENA_CALIDAD = 77;
    final  int MALA_CALIDAD = 78;

    public void eliminarDefectos();

    public void mejorarCalidad();
}
