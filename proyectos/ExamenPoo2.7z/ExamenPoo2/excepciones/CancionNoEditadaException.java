package ExamenPoo2.excepciones;

public class CancionNoEditadaException extends Exception {
    private static final long serialVersionUID = 1L;
    
    public CancionNoEditadaException  (String msg){
        super(msg);
    
}

	public String mensajeError() {
        String mensaje = "La cancion no esta editada";
		return mensaje;
	}
}
