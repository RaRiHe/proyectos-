package ExamenPoo2.excepciones;

public class DiscoIncompletoException extends Exception {
    private static final long serialVersionUID = 1L;
    
    public DiscoIncompletoException  (String msg){
        super(msg);
    
}

	public String mensajeError() {
        String mensaje ="El disco esta incompleto";
		return mensaje;
	}
}
