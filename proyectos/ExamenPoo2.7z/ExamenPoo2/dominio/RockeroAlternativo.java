package ExamenPoo2.dominio;

public class RockeroAlternativo extends Rockero {

    public RockeroAlternativo(String nombre) {
        super(nombre);
        
    }
    public String toString(){
        return "Rokero Alternativo";
    }
    
}
