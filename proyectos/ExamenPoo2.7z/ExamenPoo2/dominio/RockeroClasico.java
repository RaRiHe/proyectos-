package ExamenPoo2.dominio;

public class RockeroClasico extends Rockero {

    public RockeroClasico(String nombre) {
        super(nombre);
        
    }
    public String toString(){
        return "Rokero Clasico";
    }
    
}
