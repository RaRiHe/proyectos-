package dominio;

import interfaces.Remasterizable;

public class Canción implements Remasterizable, Comparable<Canción> {
    private String titulo;
    private int duracion;
    private int defectos;
    private int calidad;

    public Canción(String titulo, int duracion) {
        this.titulo = titulo;
        this.duracion = duracion;
        this.defectos=CON_DEFECTOS;
        this.calidad=MALA_CALIDAD;
    }
    public String getTitulo() {
        return titulo;
    }

    public int getDuracion() {
        return duracion;
    }
    
    @Override
    public void eliminarDefectos() {
       this.defectos=SIN_DEFECTOS;

    }

    @Override
    public void mejorarCalidad() {
       this.calidad=BUENA_CALIDAD;

    }
    

    @Override
    public int compareTo(Canción o) {
        int resultado=0;
        if (this.duracion< o.duracion ) {  
            return -1;
        }else if (this.duracion> o.duracion ) {  
            return  1;     
        }else{
            return this.titulo.compareTo(o.titulo);
        }
        return resultado;
       
    }
   
    
    public  boolean estaEditada(){
        if (this.defectos==33&&this.calidad==77){
            return true;
        }
        return false;
    }

  
    
}
