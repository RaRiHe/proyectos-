package dominio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import ExamenPoo2.excepciones.CancionNoEditadaException;
import ExamenPoo2.excepciones.DiscoIncompletoException;

public class Disco {
    private String titulo;
    private Rockero autor;
    private ArrayList<Canción> listaCanciones=new ArrayList<Canción>();

    public Disco(String titulo, Rockero autor) {
        this.titulo = titulo;
        this.autor = autor;
    }
    public String getTitulo() {
        return titulo;
    }
    public boolean estaCompleto(){
        if (listaCanciones.size()>=4){
            return true;
        }
        return false;
    }

    public void ordenarCanciones(){
        Collections.sort(this.listaCanciones);
        
    }

    public void anyadirCancion(Canción c)throws CancionNoEditadaException{
            if (c.estaEditada()) {
                listaCanciones.add(c);
            }else {
                throw new CancionNoEditadaException("La cancion no esta editada");
            }
    
    }

    public void imprimirDisco()throws DiscoIncompletoException{
        
        if (this.estaCompleto()) {
            System.out.println(autor.toString()+autor.getNombre());
            System.out.println("Titulo: "+this.getTitulo());
            System.out.println("");
            Iterator it = listaCanciones.iterator();
            while ( it.hasNext() ) {
            Object objeto = it.next();
            Canción cancion = (Canción)objeto;
            System.out.println(cancion.getTitulo()+"duracion: "+cancion.getDuracion()+" seg");
            }
        }else {
            throw new DiscoIncompletoException("El disco no esta completo");
        }
    }
}
