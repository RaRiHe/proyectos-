package ExamenPoo2.dominio;

public abstract class Rockero {
    private static int numRockeros;
    private String nombre;
    

    public Rockero(String nombre) {
        this.nombre = nombre;
        numRockeros++;
    }

    public static int getNumRockeros() {
        return numRockeros;
    }

    public String getNombre() {
        return nombre;
    }
    
}
