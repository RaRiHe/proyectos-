package comparar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
class Tarea implements Comparable<Tarea>{
	int duracion=0;
	String nombre ="";
	public Tarea(int duracion, String nombre) {
		this.duracion = duracion;
		this.nombre = nombre;
	}
	

	@Override
	public String toString() {
		return "Tarea [duracion=" + duracion + ", nombre=" + nombre + "]";
	}


	@Override
	public int compareTo(Tarea o) {
		
		return this.duracion-o.duracion;
	}

	
}

public class comparar2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		ArrayList<Tarea> lista = new ArrayList<Tarea>();
		
		lista.add(new Tarea(30,"DI"));
		lista.add(new Tarea(15,"AC"));
		lista.add(new Tarea(60,"PC"));
		lista.add(new Tarea(25,"FG"));
		lista.add(new Tarea(120,"FG"));
		lista.add(new Tarea(2,"FG"));
		
		Collections.sort(lista);
		System.out.println(lista);

	}

}
