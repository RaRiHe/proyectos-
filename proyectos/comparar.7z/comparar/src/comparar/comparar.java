package comparar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class comparar {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.add(30);
		lista.add(15);
		lista.add(60);
		lista.add(10);
		lista.add(120);
		Collections.sort(lista);
		System.out.println(lista);
		
	}

}
