import java.util.Scanner;

public class conecta {
	public static void imprimirTablero(int[][] tablero) {

		System.out.println("\n|     |     |     |     |     |     |     |");

		for (int i = 0; i < tablero.length; i++) {

			for (int j = 0; j < tablero[0].length; j++) {

				if (tablero[i][j] == 0) {
					System.out.printf("│%3s  ", " ");
				} else {
					if (tablero[i][j] == 1) {
						System.out.printf("│%3s  ", "X");
					} else {
						System.out.printf("│%3s  ", "O");
					}
				}
			}

			if (i != tablero.length - 1) {
				System.out.println("│\n├─────┼─────┼─────┼─────┼─────┼─────┼─────┤");
			}
		}

		System.out.println("│\n└─────┴─────┴─────┴─────┴─────┴─────┴─────┘");
		System.out.println("   1     2     3     4     5     6     7   ");
	}
	public static boolean empate (int [][] m) {
		for (int i = 0; i < m.length+1; i++) {
			if (m[0][i]==0) {
				return false;
			}
		}
		
		return true;
	}

	public static int[][] rellena(int m[][], int col, int ju) {
		for (int i = m[0].length - 2; i >= 0; i--) {
			if (m[i][col] == 0) {
				try {
					m[i][col] = ju;
					break;
				} catch (Exception e) {
					System.err.println("maximo de fichas en esta columna ");
				}
			}

		}
		return m;
	}

	public static boolean win(int[][] m, int ju) {
		// validar de arriba abajo
		for (int i = 0; i < m.length - 3; i++) {
			for (int j = 0; j < m[i].length; j++) {
				if (m[i][j] == ju && m[i + 1][j] == ju && m[i + 2][j] == ju && m[i + 3][j] == ju) {
					return true;
				}
			}
		}
		// validar de lado
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[i].length - 3; j++) {
				if (m[i][j] == ju && m[i][j + 1] == ju && m[i][j + 2] == ju && m[i][j + 3] == ju) {
					return true;
				}
			}
		}
		// Valida diagonal arriba
		for (int i = 3; i < m.length; i++) {
			for (int j = 0; j < m[i].length - 3; j++) {
				if (m[i][j] == ju && m[i - 1][j + 1] == ju && m[i - 2][j + 2] == ju && m[i - 3][j + 3] == ju) {
					return true;
				}
			}
		}

		// Valida diagonal abajo
		for (int i = 0; i < m.length - 3; i++) {
			for (int j = 0; j < m[i].length - 3; j++) {
				if (m[i][j] == ju && m[i + 1][j + 1] == ju && m[i + 2][j + 2] == ju && m[i + 3][j + 3] == ju) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean comprueva(int[][] m, int num) {
		boolean resultado = true;
		if (num < 0 || num > 7) {
			resultado = false;
		} else if (m[0][num] != 0) {
			resultado = false;
		}

		return resultado;
	}

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int m[][] = new int[6][7];
		int columna = 0;
		boolean salir = true;
		boolean correcto = true;

		imprimirTablero(m);

		while (salir) {
			correcto = true;
			while (correcto) {
				System.out.println("Jugador uno dime la columna en la cual quieres poner la ficha ");
				columna = teclado.nextInt();
				columna--;
				if (comprueva(m, columna)) {
					m = rellena(m, columna, 1);
					correcto = false;
				} else {
					System.err.println(
							" la columna esta llena o el valor es incorrecto el valor tiene que estar entre el 1 y el 7");
				}

			}
			imprimirTablero(m);
			if (empate(m)) {
				System.out.println("Se ha producido un empate");
				break;
			}
			if (win(m, 1)) {
				System.out.println("ha ganado el jugador 1");
				break;
			}
			correcto = true;
			while (correcto) {
				int cont = 0;
				System.out.println("Jugador dos dime la columna en la cual quieres poner la ficha ");
				columna = teclado.nextInt();
				columna--;
				if (comprueva(m, columna)) {
					m = rellena(m, columna, 2);
					correcto = false;

				} else {
					System.err.println(
							" la columna esta llena o el valor es incorrecto el valor tiene que estar entre el 1 y el 7");
				}

			}

			imprimirTablero(m);
			if (empate(m)) {
				System.out.println("Se ha producido un empate");
				break;
			}
			if (win(m, 2)) {
				System.out.println("ha ganado el jugador 2");
				break;
			}

		}

	}

}
