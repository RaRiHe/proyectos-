package controlador;

import java.util.Locale;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import utilidades.I18N;

public class FormularioControler {
	@FXML
	private Label lbl_titulo;
	@FXML
	private Label lbl_nombre;
	@FXML
	private Label lbl_apellido;
	@FXML
	private Label lbl_usuario;
	@FXML
	private Label lbl_contrase�a;
	@FXML
	private Label lbl_fecha;
	@FXML
	private Button guar;
	@FXML
	private Button ima;
	@FXML
	private RadioButton pro;
	@FXML
	private RadioButton bdd;
	@FXML
	private ImageView ing;
	
	
	@FXML
	void initialize() {
	    lbl_titulo.textProperty().bind(I18N.createStringBinding("form.titulo"));
		lbl_nombre.textProperty().bind(I18N.createStringBinding("form.nombre"));
		lbl_apellido.textProperty().bind(I18N.createStringBinding("form.apellidos"));
		lbl_usuario.textProperty().bind(I18N.createStringBinding("form.usuario"));
		lbl_contrase�a.textProperty().bind(I18N.createStringBinding("form.password"));
		lbl_fecha.textProperty().bind(I18N.createStringBinding("form.fecha"));
		guar.textProperty().bind(I18N.createStringBinding("form.registrar"));
		ima.textProperty().bind(I18N.createStringBinding("form.selectImagen"));
		pro.textProperty().bind(I18N.createStringBinding("form.programacion"));
		bdd.textProperty().bind(I18N.createStringBinding("form.baseDeDatos"));
		
	}
	
	@FXML
	void cast(MouseEvent event) {
		I18N.setLocale(new Locale("es"));
	}

	@FXML
	void engl(MouseEvent event) {
		I18N.setLocale(new Locale("en"));
	}
	
	@FXML
	void cata(MouseEvent event) {
		I18N.setLocale(new Locale("ca"));
	}
}
