package FlujoDeObjetos;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class almacen {

	public void  guardar(persona p , String f) {
		ObjectOutputStream out=null;
		try {
			out =new ObjectOutputStream(new FileOutputStream(f));
			out.writeObject(p);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			cerrar(out);
		}
		
	}
	

	public persona recuperar(String f) {
		persona p=null;
		ObjectInputStream in=null;
		try {
			in=new ObjectInputStream(new FileInputStream(f));
			p=(persona)in.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println("error en el fichero no se a encontrado  ");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println("Error IO ");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			cerrar(in);
		}
		
		return p;
		
		
		
		
	}
	
	public void cerrar (Closeable c) {
		try {
			if(c!=null) {
				c.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
