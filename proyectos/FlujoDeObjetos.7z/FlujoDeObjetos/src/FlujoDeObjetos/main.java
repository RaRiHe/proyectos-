package FlujoDeObjetos;

public class main {

	public static void main(String[] args) {
		persona p1=new persona("raul","rios");
		persona p2=new persona("segi","alamar");
		persona p3=new persona("fistro","wade");
		
		p1.imprimir();
		p2.imprimir();
		p3.imprimir();
		almacen al=new almacen();
		al.guardar(p1,"almacen.dat");
		
		p2= al.recuperar("almacen.dat");
		p2.imprimir();
	}

}
