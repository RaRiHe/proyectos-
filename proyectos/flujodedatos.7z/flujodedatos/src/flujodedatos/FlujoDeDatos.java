package flujodedatos;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FlujoDeDatos {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader leerArchivo = new FileReader("lectura.txt");
		FileWriter escribirArchivo=new FileWriter("eacritura.txt");
		
		int caracter=0;
		caracter=leerArchivo.read();
		escribirArchivo.write(caracter);
		while (caracter!=-1) {
			System.out.print((char)caracter);
			caracter=leerArchivo.read();
			
		}
		escribirArchivo.close();
		
	}

}
